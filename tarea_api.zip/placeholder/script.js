class Result {
    ok;
    err;
    constructor(ok, err) {
        this.ok = ok;
        this.err = err;
    }
    static ok(value) {
        return new Result(value, null);
    }
    static err(error) {
        return new Result(null, error);
    }
    is_ok() {
        return this.err === null;
    }
    is_err() {
        return this.ok === null;
    }
    unwrap() {
        if (this.is_err()) {
            throw new Error(`Called unwrap() on an Err value: ${this.err}`);
        }
        return this.ok;
    }
    unwrap_err() {
        if (this.is_ok()) {
            throw new Error(`Called unwrap_err() on an Ok value: ${this.ok}`);
        }
        return this.err;
    }
    unwrap_or(default_value) {
        return this.is_ok() ? this.ok : default_value;
    }
    to_tuple() {
        return [this.ok, this.err];
    }
}
const API_URL = 'https://jsonplaceholder.typicode.com/posts';
let last_idx = 0;
let G_posts = new Map();
async function fetch_json(url, options) {
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            return Result.err(new Error(`HTTP error ${response.status}`));
        }
        const json_data = await response.json();
        return Result.ok(json_data);
    }
    catch (error) {
        return Result.err(new Error('Network error or invalid JSON'));
    }
}
async function get_posts() {
    let re = await fetch_json(API_URL, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
    });
    if (re.is_err()) {
        return Result.err(re.unwrap_err());
    }
    let posts = re.unwrap();
    let map = new Map;
    last_idx = posts.length;
    posts.forEach(val => {
        map.set(val.id, val);
    });
    return Result.ok(map);
}
async function create_post(data) {
    let ndata = { userId: 1, ...data };
    let result = await fetch_json(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ndata)
    });
    return result;
}
async function delete_post(post_id) {
    const response = await fetch(`${API_URL}/${post_id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
    });
    if (response.status === 200) {
        return Result.ok({ success: true });
    }
    else {
        return Result.err(new Error(`Failed to delete post with ID: ${post_id}`));
    }
}
function format_post(title, body, id) {
    let div_c = document.createElement('div');
    div_c.classList.add('post')
    let div_t = document.createElement('h2');
    div_t.classList.add('post')
    let div_b = document.createElement('div');
    div_b.classList.add('post-body')
    let but_d = document.createElement('button');
    but_d.classList.add('post')
    but_d.onclick = async (_) => {
        let r = await delete_post(id);
        if (r.is_ok()) {
            G_posts.delete(id);
            div_c.remove();
            return;
        }
    };
    div_t.innerText = title;
    div_b.innerText = body;
    but_d.innerText = 'x';
    div_c.appendChild(div_t);
    div_c.appendChild(but_d);
    div_c.appendChild(div_b);
    return div_c;
}
function display_posts() {
    G_posts.forEach(post => {
        let div = format_post(post.title, post.body, post.id);
        let div_posts = document.getElementById('posts');
        div_posts.appendChild(div);
    });
}
function main() {
    get_posts().then(result => {
        if (result.is_err()) {
            console.error(result.unwrap_err());
            return;
        }
        G_posts = result.unwrap();
        display_posts();
    });
    document.getElementById('new-post').addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('new-title').value;
        const body = document.getElementById('new-body').value;
        let new_post = await create_post({ title, body });
        if (new_post.is_ok()) {
            let post = new_post.unwrap();
            G_posts.set(last_idx, post);
            let div = format_post(post.title, post.body, post.id);
            let div_posts = document.getElementById('posts');
            div_posts.appendChild(div);
            last_idx += 1;
        }
    });
}
main();
