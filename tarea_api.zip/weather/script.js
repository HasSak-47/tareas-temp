const API_KEY = "055a71e5ea992791106866e12ca71a2d";

function err(e){
    return [null, new Error(e)]
}

function ok(k){
    return [k, null]
}

function unwrap(a){
    if(a[1] != null){
        throw a[1];
    }
    return a[0];
}

async function trycatch(f, ...args){
        try{ return ok(await f(...args)); }
        catch (e){ return err(e); }
}

async function get_weather(city) {

    let url = new URL("https://api.openweathermap.org/data/2.5/weather");
    url.search = new URLSearchParams({
        q: city,
        appid: API_KEY
    });

    let [response, fetch_error] = await trycatch(fetch, url);
    if (fetch_error) return err(`Network error: ${fetch_error.message}`);

    if (!response.ok)
        return err( 
            response.status === 400 ? 'Error 400: Bad request - The city might not exist.' :
            response.status === 404 ? 'Error 404: City not found.' :
            `Error ${response.status}: ${response.statusText}`
        );

    let [data, json_error] = await trycatch(async _ => response.json());
    if (json_error) return err(json_error);

    return ok(data);
}

async function main(){
    document.getElementById('city-button').onclick = async _ => {
        let city = document.getElementById('city-name').value.trim();
        let [data, err] = await get_weather(city);
        if (err != null){
            alert('ciudad no valida!');
            document.getElementById('output').innerText = '';
            return;
        }

        document.getElementById('output').innerText = data.weather[0]['description'];
    }
}

main();
